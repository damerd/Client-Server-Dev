from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    def __init__(self):
        try:
            self.client = MongoClient("mongodb://localhost:27017")
            self.database = self.client["aac"]
            self.collection = self.database["animals"]
        except PyMongoError as exc:
            raise Exception(f"Failed to connect to MongoDB: {exc}")

    def create(self, data):
        if not data:
            raise ValueError("Nothing to save, because data parameter is empty")

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as exc:
            print(f"Create failed: {exc}")
            return False

    def read(self, query):
        try:
            return list(self.collection.find(query))
        except PyMongoError as exc:
            print(f"Read failed: {exc}")
            return []

    def update(self, query, new_values):
        if not query or not new_values:
            raise ValueError("Query and new_values cannot be empty")

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as exc:
            print(f"Update failed: {exc}")
            return 0

    def delete(self, query):
        if not query:
            raise ValueError("Query cannot be empty for delete")

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as exc:
            print(f"Delete failed: {exc}")
            return 0