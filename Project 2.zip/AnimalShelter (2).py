from pymongo import MongoClient

class AnimalShelter:

    def __init__(self, username, password):
        self.client = MongoClient(f"mongodb://{username}:{password}@localhost:27017/aac")
        self.database = self.client["aac"]
        self.collection = self.database["animals"]

    def create(self, data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print("Create failed:", e)
                return False
        return False

    def read(self, query):
        try:
            results = self.collection.find(query)
            return list(results)
        except Exception as e:
            print("Read failed:", e)
            return []

    def update(self, query, new_values):
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            print("Update failed:", e)
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print("Delete failed:", e)
            return 0